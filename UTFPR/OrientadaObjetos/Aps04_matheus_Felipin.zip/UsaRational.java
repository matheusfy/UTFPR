public class UsaRational
{

    public static void main(String[] args)
    {
        Rational num1 = new Rational();
        num1.Insere(2,4);
        num1.multiplica(2,2);
        num1.divide(2,3);
        num1.Imprime();
    }
}
